-- =============================================
-- CENSUS MANAGEMENT SYSTEM — DATABASE SCRIPT
-- Run this FIRST in SQL Server Management Studio
-- =============================================

CREATE DATABASE CensusDB;
GO
USE CensusDB;
GO

-- ─────────────────────────────────────────────
-- TABLE 1: Users  (people who LOGIN to the app)
-- ─────────────────────────────────────────────
CREATE TABLE Users (
    UserID       INT IDENTITY(1,1) PRIMARY KEY,
    FullName     NVARCHAR(100) NOT NULL,
    Email        NVARCHAR(150) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(256) NOT NULL,
    CreatedAt    DATETIME DEFAULT GETDATE()
);

-- ─────────────────────────────────────────────
-- TABLE 2: Areas  (Province / District / Tehsil)
-- ─────────────────────────────────────────────
CREATE TABLE Areas (
    AreaID    INT IDENTITY(1,1) PRIMARY KEY,
    Province  NVARCHAR(100) NOT NULL,
    District  NVARCHAR(100) NOT NULL,
    Tehsil    NVARCHAR(100) NOT NULL
);

-- ─────────────────────────────────────────────
-- TABLE 3: Households
-- ─────────────────────────────────────────────
CREATE TABLE Households (
    HouseholdID     INT IDENTITY(1,1) PRIMARY KEY,
    HouseNumber     NVARCHAR(50)  NOT NULL,
    FamilyNumber    NVARCHAR(50)  NOT NULL,
    HeadOfFamily    NVARCHAR(100) NOT NULL,
    Address         NVARCHAR(255) NOT NULL,
    NumberOfMembers INT           NOT NULL DEFAULT 1,
    AreaID          INT           NOT NULL,
    CreatedAt       DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (AreaID) REFERENCES Areas(AreaID)
);

-- ─────────────────────────────────────────────
-- TABLE 4: Citizens  (people whose census is done)
-- ─────────────────────────────────────────────
CREATE TABLE Citizens (
    CitizenID        INT IDENTITY(1,1) PRIMARY KEY,
    CNICNumber       NVARCHAR(13)  NOT NULL UNIQUE,
    FullName         NVARCHAR(100) NOT NULL,
    Gender           NVARCHAR(10)  NOT NULL,   -- Male / Female / Other
    DateOfBirth      DATE          NOT NULL,
    Age              INT           NOT NULL,
    MaritalStatus    NVARCHAR(20)  NOT NULL,
    Education        NVARCHAR(50)  NOT NULL,
    Occupation       NVARCHAR(100) NOT NULL,
    RelationWithHead NVARCHAR(50)  NOT NULL,
    HouseholdID      INT           NOT NULL,
    FOREIGN KEY (HouseholdID) REFERENCES Households(HouseholdID)
);

-- ─────────────────────────────────────────────
-- SEED: Sample Areas
-- ─────────────────────────────────────────────
INSERT INTO Areas (Province, District, Tehsil) VALUES
('Punjab',               'Rawalpindi', 'Rawalpindi City'),
('Punjab',               'Lahore',     'Lahore City'),
('Sindh',                'Karachi',    'Karachi Central'),
('Khyber Pakhtunkhwa',   'Peshawar',   'Peshawar City'),
('Balochistan',          'Quetta',     'Quetta City');

GO
PRINT 'CensusDB created successfully!';
