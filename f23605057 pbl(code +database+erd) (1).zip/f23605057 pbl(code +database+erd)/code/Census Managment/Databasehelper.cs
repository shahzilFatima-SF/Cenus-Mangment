﻿// File: Database/DatabaseHelper.cs
using System;
using System.Data;
using System.Data.SqlClient;

namespace CensusMS.Database
{
    public static class DatabaseHelper
    {
        // ── Change server name if needed ─────────────────────────────────────
        // Common options:
        //   .\SQLEXPRESS      (SQL Server Express)
        //   localhost         (default instance)
        //   (localdb)\MSSQLLocalDB  (LocalDB)
        private static readonly string ConnectionString =
           @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CensusDB;Integrated Security=True";
        // ─────────────────────────────────────────────────────────────────────

        public static SqlConnection GetConnection()
        {
            var conn = new SqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        // INSERT / UPDATE / DELETE
        public static int ExecuteNonQuery(string sql, SqlParameter[] p = null)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (p != null) cmd.Parameters.AddRange(p);
                return cmd.ExecuteNonQuery();
            }
        }

        // SELECT → DataTable
        public static DataTable ExecuteQuery(string sql, SqlParameter[] p = null)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (p != null) cmd.Parameters.AddRange(p);
                var dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        // SELECT → single value
        public static object ExecuteScalar(string sql, SqlParameter[] p = null)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (p != null) cmd.Parameters.AddRange(p);
                return cmd.ExecuteScalar();
            }
        }

        public static bool TestConnection()
        {
            try { using (GetConnection()) { } return true; }
            catch { return false; }
        }
    }
}