﻿// File: Helpers/SessionManager.cs
namespace CensusMS.Helpers
{
    public static class SessionManager
    {
        public static int UserID { get; set; }
        public static string FullName { get; set; }
        public static string Email { get; set; }

        public static void Clear()
        {
            UserID = 0;
            FullName = null;
            Email = null;
        }
    }
}
