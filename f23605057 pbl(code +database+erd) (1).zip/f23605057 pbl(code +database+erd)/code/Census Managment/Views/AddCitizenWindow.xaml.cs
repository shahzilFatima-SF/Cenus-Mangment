﻿// File: Views/AddCitizenWindow.xaml.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using CensusMS.Database;

namespace CensusMS.Views
{
    public partial class AddCitizenWindow : Window
    {
        private readonly HomeWindow _home;

        public AddCitizenWindow(HomeWindow home)
        {
            InitializeComponent();
            _home = home;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Load households for the combo
            DataTable dt = DatabaseHelper.ExecuteQuery(
                @"SELECT HouseholdID,
                         HouseNumber + ' — ' + HeadOfFamily AS HouseLabel
                  FROM Households ORDER BY HouseNumber");
            CmbHousehold.ItemsSource = dt.DefaultView;
        }

        private void DpDOB_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (DpDOB.SelectedDate.HasValue)
            {
                int age = DateTime.Today.Year - DpDOB.SelectedDate.Value.Year;
                if (DpDOB.SelectedDate.Value > DateTime.Today.AddYears(-age)) age--;
                TxtAge.Text = age >= 0 ? age.ToString() : "0";
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            TxtError.Visibility = Visibility.Collapsed;
            TxtSuccess.Visibility = Visibility.Collapsed;

            string cnic = TxtCNIC.Text.Trim();
            string name = TxtName.Text.Trim();
            string occ = TxtOcc.Text.Trim();

            // ── Empty check ──────────────────────────────────────────────────
            if (string.IsNullOrEmpty(cnic) || string.IsNullOrEmpty(name) ||
                CmbGender.SelectedItem == null || DpDOB.SelectedDate == null ||
                CmbMarital.SelectedItem == null || CmbEdu.SelectedItem == null ||
                string.IsNullOrEmpty(occ) || CmbRelation.SelectedItem == null ||
                CmbHousehold.SelectedValue == null)
            { ShowErr("All fields are required."); return; }

            // ── CNIC format: exactly 13 digits ───────────────────────────────
            if (!Regex.IsMatch(cnic, @"^\d{13}$"))
            { ShowErr("CNIC must be exactly 13 digits — no dashes, no spaces."); return; }

            // ── Age validation ───────────────────────────────────────────────
            if (!int.TryParse(TxtAge.Text, out int age) || age < 0)
            { ShowErr("Invalid date of birth."); return; }

            // ── Duplicate CNIC check ─────────────────────────────────────────
            int dup = Convert.ToInt32(DatabaseHelper.ExecuteScalar(
                "SELECT COUNT(*) FROM Citizens WHERE CNICNumber = @C",
                new[] { new SqlParameter("@C", cnic) }));
            if (dup > 0) { ShowErr("A citizen with this CNIC is already registered."); return; }

            // ── Insert ───────────────────────────────────────────────────────
            string gender = GetCombo(CmbGender);
            string marital = GetCombo(CmbMarital);
            string edu = GetCombo(CmbEdu);
            string relation = GetCombo(CmbRelation);
            int householdID = (int)CmbHousehold.SelectedValue;

            DatabaseHelper.ExecuteNonQuery(
                @"INSERT INTO Citizens
                  (CNICNumber, FullName, Gender, DateOfBirth, Age,
                   MaritalStatus, Education, Occupation, RelationWithHead, HouseholdID)
                  VALUES (@C, @N, @G, @DOB, @Age, @Mar, @Edu, @Occ, @Rel, @HH)",
                new[] {
                    new SqlParameter("@C",   cnic),
                    new SqlParameter("@N",   name),
                    new SqlParameter("@G",   gender),
                    new SqlParameter("@DOB", DpDOB.SelectedDate.Value),
                    new SqlParameter("@Age", age),
                    new SqlParameter("@Mar", marital),
                    new SqlParameter("@Edu", edu),
                    new SqlParameter("@Occ", occ),
                    new SqlParameter("@Rel", relation),
                    new SqlParameter("@HH",  householdID)
                });

            // Show success and reset form
            TxtSuccess.Visibility = Visibility.Visible;
            ClearForm();

            // Refresh dashboard stats in background
            _home.LoadStats();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e) => Close();

        // ── Helpers ──────────────────────────────────────────────────────────
        private string GetCombo(ComboBox cmb)
            => (cmb.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "";

        private void ClearForm()
        {
            TxtCNIC.Clear(); TxtName.Clear(); TxtOcc.Clear(); TxtAge.Clear();
            CmbGender.SelectedIndex = -1;
            DpDOB.SelectedDate = null;
            CmbMarital.SelectedIndex = -1;
            CmbEdu.SelectedIndex = -1;
            CmbRelation.SelectedIndex = -1;
            CmbHousehold.SelectedIndex = -1;
        }

        private void ShowErr(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}