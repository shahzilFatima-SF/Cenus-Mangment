﻿// File: Views/SplashScreen.xaml.cs
using System;
using System.Windows;
using System.Windows.Threading;

namespace CensusMS.Views
{
    public partial class SplashScreen : Window
    {
        private DispatcherTimer timer;

        public SplashScreen()
        {
            InitializeComponent();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(5);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();

            // first run → signup
            new SignupWindow().Show();

            // if login instead:
            // new LoginWindow().Show();

            this.Close();
        }
    }
}