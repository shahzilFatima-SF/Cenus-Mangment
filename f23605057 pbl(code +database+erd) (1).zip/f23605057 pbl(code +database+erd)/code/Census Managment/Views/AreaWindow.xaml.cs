﻿// File: Views/AreaWindow.xaml.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using CensusMS.Database;

namespace CensusMS.Views
{
    public partial class AreaWindow : Window
    {
        private readonly HomeWindow _home;
        private int _selectedID = 0;
        private DataTable _data = new DataTable();

        public AreaWindow(HomeWindow home)
        {
            InitializeComponent();
            _home = home;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) => Load();

        private void Load()
        {
            _data = DatabaseHelper.ExecuteQuery(
                "SELECT AreaID, Province, District, Tehsil FROM Areas ORDER BY Province, District");
            DgAreas.ItemsSource = _data.DefaultView;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!Validate()) return;

            DatabaseHelper.ExecuteNonQuery(
                "INSERT INTO Areas (Province, District, Tehsil) VALUES (@P, @D, @T)",
                Params());

            Clear(); Load();
            MessageBox.Show("Area added.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedID == 0) { ShowErr("Select a row first."); return; }
            if (!Validate()) return;

            DatabaseHelper.ExecuteNonQuery(
                "UPDATE Areas SET Province=@P, District=@D, Tehsil=@T WHERE AreaID=@ID",
                new[] {
                    new SqlParameter("@P",  TxtProvince.Text.Trim()),
                    new SqlParameter("@D",  TxtDistrict.Text.Trim()),
                    new SqlParameter("@T",  TxtTehsil.Text.Trim()),
                    new SqlParameter("@ID", _selectedID)
                });

            Clear(); Load();
            MessageBox.Show("Area updated.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedID == 0) { ShowErr("Select a row first."); return; }

            // Check if any household uses this area
            int used = Convert.ToInt32(DatabaseHelper.ExecuteScalar(
                "SELECT COUNT(*) FROM Households WHERE AreaID=@ID",
                new[] { new SqlParameter("@ID", _selectedID) }));
            if (used > 0)
            {
                MessageBox.Show("Cannot delete — this area has households linked to it.",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Delete this area?", "Confirm",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("DELETE FROM Areas WHERE AreaID=@ID",
                    new[] { new SqlParameter("@ID", _selectedID) });
                Clear(); Load();
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e) => Clear();

        private void DgAreas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DgAreas.SelectedItem is DataRowView row)
            {
                _selectedID = (int)row["AreaID"];
                TxtProvince.Text = row["Province"].ToString();
                TxtDistrict.Text = row["District"].ToString();
                TxtTehsil.Text = row["Tehsil"].ToString();
                TxtError.Visibility = Visibility.Collapsed;
            }
        }

        private void TxtSearch_Changed(object sender, TextChangedEventArgs e)
        {
            string kw = TxtSearch.Text.Trim();
            _data.DefaultView.RowFilter = string.IsNullOrEmpty(kw) ? "" :
                $"Province LIKE '%{kw}%' OR District LIKE '%{kw}%' OR Tehsil LIKE '%{kw}%'";
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e) => Close();

        private bool Validate()
        {
            if (string.IsNullOrEmpty(TxtProvince.Text.Trim()) ||
                string.IsNullOrEmpty(TxtDistrict.Text.Trim()) ||
                string.IsNullOrEmpty(TxtTehsil.Text.Trim()))
            { ShowErr("All three fields are required."); return false; }
            TxtError.Visibility = Visibility.Collapsed;
            return true;
        }

        private SqlParameter[] Params() => new[]
        {
            new SqlParameter("@P", TxtProvince.Text.Trim()),
            new SqlParameter("@D", TxtDistrict.Text.Trim()),
            new SqlParameter("@T", TxtTehsil.Text.Trim())
        };

        private void Clear()
        {
            _selectedID = 0;
            TxtProvince.Clear(); TxtDistrict.Clear(); TxtTehsil.Clear();
            TxtError.Visibility = Visibility.Collapsed;
        }

        private void ShowErr(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}