﻿using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using Census_Managment;
using CensusMS.Database;
using CensusMS.Helpers;

namespace CensusMS.Views
{
    public partial class SignupWindow : Window
    {
        public SignupWindow() => InitializeComponent();

        private void Window_Loaded(object sender, RoutedEventArgs e) { }

        private void BtnSignup_Click(object sender, RoutedEventArgs e)
        {
            string name = TxtName.Text.Trim();
            string email = TxtEmail.Text.Trim();
            string pass = PwdPass.Password;
            string confirm = PwdConfirm.Password;

            // ── Validations ──────────────────────────────────────────────────
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass))
            { ShowError("All fields are required."); return; }

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            { ShowError("Enter a valid email address."); return; }

            if (pass.Length < 6)
            { ShowError("Password must be at least 6 characters."); return; }

            if (pass != confirm)
            { ShowError("Passwords do not match."); return; }

            // ── Check duplicate email ────────────────────────────────────────
            int exists = Convert.ToInt32(DatabaseHelper.ExecuteScalar(
                "SELECT COUNT(*) FROM Users WHERE Email = @E",
                new[] { new SqlParameter("@E", email) }));
            if (exists > 0) { ShowError("This email is already registered."); return; }

            // ── Insert ───────────────────────────────────────────────────────
            string hash = PasswordHelper.Hash(pass);
            DatabaseHelper.ExecuteNonQuery(
                "INSERT INTO Users (FullName, Email, PasswordHash) VALUES (@N, @E, @H)",
                new[] {
                    new SqlParameter("@N", name),
                    new SqlParameter("@E", email),
                    new SqlParameter("@H", hash)
                });

            MessageBox.Show("Account created! Please log in.", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);

            new LoginWindow().Show();
            Close();
        }

        private void GoToLogin_Click(object sender, MouseButtonEventArgs e)
        {
            new LoginWindow().Show();
            Close();
        }

        private void ShowError(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}