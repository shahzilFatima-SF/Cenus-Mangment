﻿// File: Views/HouseholdWindow.xaml.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using CensusMS.Database;

namespace CensusMS.Views
{
    public partial class HouseholdWindow : Window
    {
        private readonly HomeWindow _home;
        private int _selectedID = 0;
        private DataTable _data = new DataTable();

        public HouseholdWindow(HomeWindow home)
        {
            InitializeComponent();
            _home = home;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadAreaCombo();
            Load();
        }

        private void LoadAreaCombo()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery(
                "SELECT AreaID, Province + ', ' + District + ', ' + Tehsil AS AreaLabel FROM Areas ORDER BY Province");
            CmbArea.ItemsSource = dt.DefaultView;
        }

        private void Load()
        {
            string sql = @"SELECT h.HouseholdID, h.HouseNumber, h.FamilyNumber,
                                  h.HeadOfFamily, h.NumberOfMembers, h.Address,
                                  a.Province + ', ' + a.District + ', ' + a.Tehsil AS AreaLabel,
                                  h.AreaID
                           FROM Households h
                           JOIN Areas a ON h.AreaID = a.AreaID
                           ORDER BY h.HouseholdID DESC";
            _data = DatabaseHelper.ExecuteQuery(sql);
            DgHouseholds.ItemsSource = _data.DefaultView;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!Validate()) return;

            DatabaseHelper.ExecuteNonQuery(
                @"INSERT INTO Households (HouseNumber,FamilyNumber,HeadOfFamily,Address,NumberOfMembers,AreaID)
                  VALUES (@HN,@FN,@Head,@Addr,@Mem,@Area)",
                Params());

            Clear(); Load();
            MessageBox.Show("Household added.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedID == 0) { ShowErr("Select a row first."); return; }
            if (!Validate()) return;

            var p = Params();
            Array.Resize(ref p, p.Length + 1);
            p[p.Length - 1] = new SqlParameter("@ID", _selectedID);

            DatabaseHelper.ExecuteNonQuery(
                @"UPDATE Households SET HouseNumber=@HN, FamilyNumber=@FN, HeadOfFamily=@Head,
                  Address=@Addr, NumberOfMembers=@Mem, AreaID=@Area WHERE HouseholdID=@ID", p);

            Clear(); Load();
            MessageBox.Show("Household updated.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedID == 0) { ShowErr("Select a row first."); return; }

            int citizens = Convert.ToInt32(DatabaseHelper.ExecuteScalar(
                "SELECT COUNT(*) FROM Citizens WHERE HouseholdID=@ID",
                new[] { new SqlParameter("@ID", _selectedID) }));

            string msg = citizens > 0
                ? $"This household has {citizens} citizen(s). Deleting it will also delete them. Continue?"
                : "Delete this household?";

            if (MessageBox.Show(msg, "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                DatabaseHelper.ExecuteNonQuery("DELETE FROM Citizens    WHERE HouseholdID=@ID",
                    new[] { new SqlParameter("@ID", _selectedID) });
                DatabaseHelper.ExecuteNonQuery("DELETE FROM Households WHERE HouseholdID=@ID",
                    new[] { new SqlParameter("@ID", _selectedID) });
                Clear(); Load();
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e) => Clear();

        private void DgHouseholds_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DgHouseholds.SelectedItem is DataRowView row)
            {
                _selectedID = (int)row["HouseholdID"];
                TxtHouseNo.Text = row["HouseNumber"].ToString();
                TxtFamilyNo.Text = row["FamilyNumber"].ToString();
                TxtHead.Text = row["HeadOfFamily"].ToString();
                TxtMembers.Text = row["NumberOfMembers"].ToString();
                TxtAddress.Text = row["Address"].ToString();

                // Select matching area in combo
                int areaID = (int)row["AreaID"];
                foreach (DataRowView item in CmbArea.Items)
                    if ((int)item["AreaID"] == areaID) { CmbArea.SelectedItem = item; break; }

                TxtError.Visibility = Visibility.Collapsed;
            }
        }

        private void TxtSearch_Changed(object sender, TextChangedEventArgs e)
        {
            string kw = TxtSearch.Text.Trim();
            _data.DefaultView.RowFilter = string.IsNullOrEmpty(kw) ? "" :
                $"HeadOfFamily LIKE '%{kw}%' OR HouseNumber LIKE '%{kw}%' OR Address LIKE '%{kw}%'";
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e) => Close();

        private bool Validate()
        {
            if (string.IsNullOrEmpty(TxtHouseNo.Text.Trim()) ||
                string.IsNullOrEmpty(TxtFamilyNo.Text.Trim()) ||
                string.IsNullOrEmpty(TxtHead.Text.Trim()) ||
                string.IsNullOrEmpty(TxtAddress.Text.Trim()) ||
                CmbArea.SelectedValue == null)
            { ShowErr("All fields are required."); return false; }

            if (!int.TryParse(TxtMembers.Text.Trim(), out int m) || m <= 0)
            { ShowErr("Number of members must be a positive number."); return false; }

            TxtError.Visibility = Visibility.Collapsed;
            return true;
        }

        private SqlParameter[] Params() => new[]
        {
            new SqlParameter("@HN",   TxtHouseNo.Text.Trim()),
            new SqlParameter("@FN",   TxtFamilyNo.Text.Trim()),
            new SqlParameter("@Head", TxtHead.Text.Trim()),
            new SqlParameter("@Addr", TxtAddress.Text.Trim()),
            new SqlParameter("@Mem",  int.Parse(TxtMembers.Text.Trim())),
            new SqlParameter("@Area", (int)CmbArea.SelectedValue)
        };

        private void Clear()
        {
            _selectedID = 0;
            TxtHouseNo.Clear(); TxtFamilyNo.Clear(); TxtHead.Clear();
            TxtMembers.Clear(); TxtAddress.Clear();
            CmbArea.SelectedIndex = -1;
            TxtError.Visibility = Visibility.Collapsed;
        }

        private void ShowErr(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}