﻿// File: Views/CitizenWindow.xaml.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using CensusMS.Database;

namespace CensusMS.Views
{
    public partial class CitizenWindow : Window
    {
        private readonly HomeWindow _home;
        private int _selectedID = 0;
        private DataTable _data = new DataTable();
        private bool? _sortAscending = null;
        private bool _isLoaded = false; // guard flag

        public CitizenWindow(HomeWindow home)
        {
            InitializeComponent();
            _home = home;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _isLoaded = true;
            Load();
        }

        // ── Load Data ─────────────────────────────────────────────────────────
        private void Load()
        {
            try
            {
                string sql = @"SELECT c.CitizenID, c.CNICNumber, c.FullName, c.Gender,
                                      c.DateOfBirth, c.Age, c.MaritalStatus, c.Education,
                                      c.Occupation, c.RelationWithHead,
                                      h.HouseNumber
                               FROM Citizens c
                               JOIN Households h ON c.HouseholdID = h.HouseholdID
                               ORDER BY c.CitizenID DESC";

                _data = DatabaseHelper.ExecuteQuery(sql);

                if (_data == null)
                    _data = new DataTable();

                DgCitizens.ItemsSource = _data.DefaultView;
                UpdateCount();

                // Re-apply sort if one was active
                if (_sortAscending.HasValue)
                    ApplySort(_sortAscending.Value);

                // Re-apply filter if one was active
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data:\n{ex.Message}", "Load Error",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ── Grid Selection ────────────────────────────────────────────────────
        private void DgCitizens_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DgCitizens.SelectedItem is DataRowView row)
                {
                    _selectedID = Convert.ToInt32(row["CitizenID"]);

                    TxtCNIC.Text = row["CNICNumber"]?.ToString() ?? "";
                    TxtName.Text = row["FullName"]?.ToString() ?? "";
                    TxtOcc.Text = row["Occupation"]?.ToString() ?? "";

                    // Date of Birth — guard against DBNull
                    if (row["DateOfBirth"] != DBNull.Value && row["DateOfBirth"] != null)
                        DpDOB.SelectedDate = Convert.ToDateTime(row["DateOfBirth"]);
                    else
                        DpDOB.SelectedDate = null;

                    // ComboBoxes — safely set each one
                    SetCombo(CmbGender, row["Gender"]?.ToString() ?? "");
                    SetCombo(CmbMarital, row["MaritalStatus"]?.ToString() ?? "");
                    SetCombo(CmbEdu, row["Education"]?.ToString() ?? "");
                    SetCombo(CmbRelation, row["RelationWithHead"]?.ToString() ?? "");

                    EditPanel.Visibility = Visibility.Visible;
                    TxtError.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {
                ShowErr($"Selection error: {ex.Message}");
            }
        }

        // ── Save ──────────────────────────────────────────────────────────────
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!Validate()) return;

                int dup = Convert.ToInt32(DatabaseHelper.ExecuteScalar(
                    "SELECT COUNT(*) FROM Citizens WHERE CNICNumber=@C AND CitizenID <> @ID",
                    new[] { new SqlParameter("@C",  TxtCNIC.Text.Trim()),
                            new SqlParameter("@ID", _selectedID) }));

                if (dup > 0)
                {
                    ShowErr("This CNIC is already registered to another citizen.");
                    return;
                }

                int age = CalculateAge(DpDOB.SelectedDate.Value);

                DatabaseHelper.ExecuteNonQuery(
                    @"UPDATE Citizens SET
                      CNICNumber=@C, FullName=@N, Gender=@G, DateOfBirth=@DOB, Age=@Age,
                      MaritalStatus=@Mar, Education=@Edu, Occupation=@Occ,
                      RelationWithHead=@Rel
                      WHERE CitizenID=@ID",
                    new[] {
                        new SqlParameter("@C",   TxtCNIC.Text.Trim()),
                        new SqlParameter("@N",   TxtName.Text.Trim()),
                        new SqlParameter("@G",   GetCombo(CmbGender)),
                        new SqlParameter("@DOB", DpDOB.SelectedDate.Value),
                        new SqlParameter("@Age", age),
                        new SqlParameter("@Mar", GetCombo(CmbMarital)),
                        new SqlParameter("@Edu", GetCombo(CmbEdu)),
                        new SqlParameter("@Occ", TxtOcc.Text.Trim()),
                        new SqlParameter("@Rel", GetCombo(CmbRelation)),
                        new SqlParameter("@ID",  _selectedID)
                    });

                MessageBox.Show("Citizen updated successfully.", "Success",
                                MessageBoxButton.OK, MessageBoxImage.Information);
                HideEdit();
                Load();
            }
            catch (Exception ex)
            {
                ShowErr($"Save error: {ex.Message}");
            }
        }

        // ── Delete ────────────────────────────────────────────────────────────
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_selectedID == 0) return;

                if (MessageBox.Show("Delete this citizen permanently?", "Confirm",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    DatabaseHelper.ExecuteNonQuery(
                        "DELETE FROM Citizens WHERE CitizenID=@ID",
                        new[] { new SqlParameter("@ID", _selectedID) });

                    HideEdit();
                    Load();
                }
            }
            catch (Exception ex)
            {
                ShowErr($"Delete error: {ex.Message}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => HideEdit();

        private void BtnAddNew_Click(object sender, RoutedEventArgs e)
        {
            new AddCitizenWindow(_home).ShowDialog();
            Load();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e) => Close();

        // ── Search & Filter ───────────────────────────────────────────────────
        private void TxtSearch_Changed(object sender, TextChangedEventArgs e)
        {
            if (!_isLoaded || _data == null) return;
            ApplyFilter();
        }

        private void CmbFilter_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_isLoaded || _data == null) return;
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            // Guard: data not ready yet
            if (_data == null || _data.DefaultView == null) return;

            try
            {
                string kw = TxtSearch?.Text?.Trim().Replace("'", "''") ?? "";
                string gender = GetComboSafe(CmbFilter);

                string f = "";

                if (!string.IsNullOrEmpty(kw))
                    f = $"(FullName LIKE '%{kw}%' OR CNICNumber LIKE '%{kw}%')";

                if (!string.IsNullOrEmpty(gender) && gender != "All")
                {
                    if (!string.IsNullOrEmpty(f)) f += " AND ";
                    f += $"Gender = '{gender}'";
                }

                _data.DefaultView.RowFilter = f;
                UpdateCount();
            }
            catch (Exception ex)
            {
                // Silently ignore filter errors during load
                System.Diagnostics.Debug.WriteLine($"Filter error: {ex.Message}");
            }
        }

        // ── Sort ──────────────────────────────────────────────────────────────
        private void BtnSortAsc_Click(object sender, RoutedEventArgs e)
        {
            _sortAscending = true;
            ApplySort(true);
        }

        private void BtnSortDesc_Click(object sender, RoutedEventArgs e)
        {
            _sortAscending = false;
            ApplySort(false);
        }

        private void ApplySort(bool ascending)
        {
            if (_data?.DefaultView == null) return;

            try
            {
                _data.DefaultView.Sort = ascending ? "FullName ASC" : "FullName DESC";

                // Highlight active button
                var activeColor = new SolidColorBrush(Color.FromArgb(0xFF, 0xFF, 0x8C, 0x61));
                var inactiveColor = new SolidColorBrush(Color.FromArgb(0x33, 0xFF, 0xFF, 0xFF));

                if (BtnSortAsc != null)
                    BtnSortAsc.Background = ascending ? activeColor : inactiveColor;

                if (BtnSortDesc != null)
                    BtnSortDesc.Background = !ascending ? activeColor : inactiveColor;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Sort error: {ex.Message}");
            }
        }

        private void DpDOB_Changed(object sender, SelectionChangedEventArgs e) { }

        // ── Helpers ───────────────────────────────────────────────────────────

        /// <summary>
        /// Selects the ComboBoxItem whose Content matches val (case-insensitive).
        /// </summary>
        private void SetCombo(ComboBox cmb, string val)
        {
            if (cmb == null) return;
            cmb.SelectedItem = null;

            if (string.IsNullOrEmpty(val)) return;

            foreach (var obj in cmb.Items)
            {
                if (obj is ComboBoxItem item &&
                    string.Equals(item.Content?.ToString(), val,
                                  StringComparison.OrdinalIgnoreCase))
                {
                    cmb.SelectedItem = item;
                    return;
                }
            }
        }

        /// <summary>Returns selected ComboBoxItem content, or "" if nothing selected.</summary>
        private string GetCombo(ComboBox cmb)
        {
            if (cmb == null) return "";
            return (cmb.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
        }

        /// <summary>Safe version used for filter — returns "All" if nothing selected.</summary>
        private string GetComboSafe(ComboBox cmb)
        {
            if (cmb == null) return "All";
            return (cmb.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "All";
        }

        private bool Validate()
        {
            string cnic = TxtCNIC?.Text?.Trim() ?? "";

            if (string.IsNullOrEmpty(cnic) ||
                string.IsNullOrEmpty(TxtName?.Text?.Trim()) ||
                CmbGender?.SelectedItem == null ||
                DpDOB?.SelectedDate == null ||
                CmbMarital?.SelectedItem == null ||
                CmbEdu?.SelectedItem == null ||
                string.IsNullOrEmpty(TxtOcc?.Text?.Trim()) ||
                CmbRelation?.SelectedItem == null)
            {
                ShowErr("All fields are required.");
                return false;
            }

            if (!Regex.IsMatch(cnic, @"^\d{13}$"))
            {
                ShowErr("CNIC must be exactly 13 digits.");
                return false;
            }

            TxtError.Visibility = Visibility.Collapsed;
            return true;
        }

        private int CalculateAge(DateTime dob)
        {
            int age = DateTime.Today.Year - dob.Year;
            if (dob > DateTime.Today.AddYears(-age)) age--;
            return age;
        }

        private void HideEdit()
        {
            _selectedID = 0;

            if (TxtCNIC != null) TxtCNIC.Text = "";
            if (TxtName != null) TxtName.Text = "";
            if (TxtOcc != null) TxtOcc.Text = "";

            if (DpDOB != null) DpDOB.SelectedDate = null;
            if (CmbGender != null) CmbGender.SelectedItem = null;
            if (CmbMarital != null) CmbMarital.SelectedItem = null;
            if (CmbEdu != null) CmbEdu.SelectedItem = null;
            if (CmbRelation != null) CmbRelation.SelectedItem = null;

            if (EditPanel != null) EditPanel.Visibility = Visibility.Collapsed;
            if (TxtError != null) TxtError.Visibility = Visibility.Collapsed;
        }

        private void ShowErr(string msg)
        {
            if (TxtError == null) return;
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }

        private void UpdateCount()
        {
            if (_data == null || TxtCount == null) return;
            int shown = _data.DefaultView.Count;
            int total = _data.Rows.Count;
            TxtCount.Text = shown == total
                ? $"Total: {total}"
                : $"Showing: {shown} / {total}";
        }
    }
}