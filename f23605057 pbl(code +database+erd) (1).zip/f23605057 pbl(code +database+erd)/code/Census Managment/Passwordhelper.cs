﻿// File: Helpers/PasswordHelper.cs
using System.Security.Cryptography;
using System.Text;

namespace CensusMS.Helpers
{
    public static class PasswordHelper
    {
        public static string Hash(string plain)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(plain));
                var sb = new StringBuilder();
                foreach (var b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static bool Verify(string plain, string hash) => Hash(plain) == hash;
    }
}