﻿// File: Views/HomeWindow.xaml.cs
using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using CensusMS.Database;
using CensusMS.Helpers;

namespace CensusMS.Views
{
    public partial class HomeWindow : Window
    {
        private DataTable _allData = new DataTable();

        public HomeWindow() => InitializeComponent();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TxtUser.Text = $"👤  {SessionManager.FullName}";
            LoadStats();
        }

        // ── Reload stats (called after returning from sub-windows) ────────────
        public void LoadStats()
        {
            TxtHouseholds.Text = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Households")?.ToString() ?? "0";
            TxtPopulation.Text = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Citizens")?.ToString() ?? "0";
            TxtMale.Text = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Citizens WHERE Gender='Male'")?.ToString() ?? "0";
            TxtFemale.Text = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM Citizens WHERE Gender='Female'")?.ToString() ?? "0";
        }

        // ── Navigation buttons ────────────────────────────────────────────────
        private void BtnArea_Click(object sender, RoutedEventArgs e)
        {
            new AreaWindow(this).ShowDialog();
            LoadStats();
        }

        private void BtnHousehold_Click(object sender, RoutedEventArgs e)
        {
            new HouseholdWindow(this).ShowDialog();
            LoadStats();
        }

        private void BtnCitizen_Click(object sender, RoutedEventArgs e)
        {
            new CitizenWindow(this).ShowDialog();
            LoadStats();
        }

        private void BtnAddCitizen_Click(object sender, RoutedEventArgs e)
        {
            new AddCitizenWindow(this).ShowDialog();
            LoadStats();
        }

        // ── View All Data ─────────────────────────────────────────────────────
        private void BtnViewAll_Click(object sender, RoutedEventArgs e)
        {
            LoadAllData();
            PanelAllData.Visibility = Visibility.Visible;
        }

        private void BtnCloseAllData_Click(object sender, RoutedEventArgs e)
        {
            PanelAllData.Visibility = Visibility.Collapsed;
        }

        private void LoadAllData()
        {
            string sql = @"
                SELECT c.CNICNumber, c.FullName, c.Gender, c.Age,
                       c.Education, c.Occupation,
                       h.HouseNumber, h.HeadOfFamily, h.NumberOfMembers,h.Address,
                       a.Province + ', ' + a.District + ', ' + a.Tehsil AS AreaLabel
                FROM Citizens c
                JOIN Households h ON c.HouseholdID = h.HouseholdID
                JOIN Areas      a ON h.AreaID       = a.AreaID
                ORDER BY c.CitizenID DESC";

            _allData = DatabaseHelper.ExecuteQuery(sql);
            DgAllData.ItemsSource = _allData.DefaultView;
        }

        private void TxtGlobalSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string kw = TxtGlobalSearch.Text.Trim();
            if (string.IsNullOrEmpty(kw))
                _allData.DefaultView.RowFilter = "";
            else
                _allData.DefaultView.RowFilter =
                    $"FullName LIKE '%{kw}%' OR CNICNumber LIKE '%{kw}%' " +
                    $"OR HeadOfFamily LIKE '%{kw}%' OR AreaLabel LIKE '%{kw}%'";
        }

        // ── Logout ────────────────────────────────────────────────────────────
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Logout?", "Confirm", MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                SessionManager.Clear();
                new LoginWindow().Show();
                Close();
            }
        }
    }
}