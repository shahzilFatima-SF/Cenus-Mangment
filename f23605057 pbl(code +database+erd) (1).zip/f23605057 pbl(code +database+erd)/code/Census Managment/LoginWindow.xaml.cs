﻿// File: Views/LoginWindow.xaml.cs
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Input;
using Census_Managment;
using CensusMS.Database;
using CensusMS.Helpers;

namespace CensusMS.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow() => InitializeComponent();

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = TxtEmail.Text.Trim();
            string pass = PwdPass.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass))
            { ShowError("Email and password are required."); return; }

            DataTable dt = DatabaseHelper.ExecuteQuery(
                "SELECT UserID, FullName, PasswordHash FROM Users WHERE Email = @E",
                new[] { new SqlParameter("@E", email) });

            if (dt.Rows.Count == 0) { ShowError("Invalid email or password."); return; }

            DataRow row = dt.Rows[0];
            if (!PasswordHelper.Verify(pass, row["PasswordHash"].ToString()))
            { ShowError("Invalid email or password."); return; }

            // Set session
            SessionManager.UserID = (int)row["UserID"];
            SessionManager.FullName = row["FullName"].ToString();
            SessionManager.Email = email;

            new HomeWindow().Show();
            Close();
        }

        private void GoToSignup_Click(object sender, MouseButtonEventArgs e)
        {
            new SignupWindow().Show();
            Close();
        }

        private void ShowError(string msg)
        {
            TxtError.Text = msg;
            TxtError.Visibility = Visibility.Visible;
        }
    }
}